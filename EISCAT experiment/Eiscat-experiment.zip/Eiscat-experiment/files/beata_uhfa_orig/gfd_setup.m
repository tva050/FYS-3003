name_expr= 'beata';
expver= 2;
siteid= 3;
data_path= '/data/beata_cp1_2.2u_NO@uhf';
result_path= '/analysis/results/AUTO';
t1=[ 2023 3 14 8 0 0];
t2=[ 2023 3 14 24 0 0];
rt= 1;
intper= 60;
path_exps= '/analysis/guisdap9/exps/';
figs=[ 1 1 1 1 1];
extra=[ '%Magic_const=1.0;      '
 'a_satch.prep=357120;   '
 '%analysis_plasmaline=1;'
 'analysis_sweep=''elaz''; '];
