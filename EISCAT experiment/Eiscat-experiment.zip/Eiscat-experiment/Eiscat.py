import numpy as np
from scipy.io import loadmat
from datetime import datetime
import os
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import time
import matplotlib.ticker as ticker

def guisdap_param2cell2regular(mat_files, time_limits=None):
    """ Not my code! """
    # Check if time_limits is provided, and read only files between start and stop times
    if time_limits is not None:
        mat_files = [f for f in mat_files if time_limits[0] <= int(os.path.splitext(f.name)[0]) <= time_limits[1]]
    mat = loadmat(mat_files[0])
    n_alt = len(mat['r_h'])
    n_files = len(mat_files)
    h = np.zeros((n_alt, n_files))
    t = np.zeros(n_files)
    ne = np.zeros((n_alt,n_files))
    Te = np.zeros((n_alt, n_files))
    Ti = np.zeros((n_alt, n_files))
    vi = np.zeros((n_alt, n_files))
    dne = np.zeros((n_alt, n_files))
    dTe = np.zeros((n_alt, n_files))
    dTi = np.zeros((n_alt, n_files))
    dvi = np.zeros((n_alt, n_files))
    az = np.zeros((n_alt, n_files))
    el = np.zeros((n_alt, n_files))
    T = np.zeros((n_files, 6))
    ranges = np.zeros((n_alt, n_files))

    for i1, f in enumerate(mat_files):
        # Load mat file
        mat = loadmat(f)

        # Extract data from mat file
        ne[:,i1] = mat['r_param'][:, 0]
        Ti[:,i1] = mat['r_param'][:, 1]
        Te[:,i1] = mat['r_param'][:, 2] * mat['r_param'][:, 1]
        vi[:,i1] = mat['r_param'][:, 4]
        dne[:,i1] = mat['r_error'][:, 0]
        dTi[:,i1] = mat['r_error'][:, 1]
        dTe[:,i1] = mat['r_error'][:, 2]
        dvi[:,i1] = mat['r_error'][:, 4]
        az[:,i1] = mat['r_az']
        el[:,i1] = mat['r_el']
        t[i1] = date2unix(mat['r_time'][0])
        T[i1, :] = mat['r_time'][0]
        h[:,i1] = mat['r_h'][:,0]
        ranges[:,i1] = mat['r_range'][:,0]

    return h, t, ne, Te, Ti, vi, dne, dTe, dTi, dvi, az, el, T, ranges

def date2unix(utc_date):
    """ Not my code! """
    year = int(utc_date[0])
    month = int(utc_date[1])
    day = int(utc_date[2])
    hour = int(utc_date[3])
    minute = int(utc_date[4])
    second = int(utc_date[5])

    number_of_day_before_day_one = datetime(1970, 1, 1).toordinal() - 1
    absolute_number_of_day = datetime(year, month, day).toordinal()
    julian_day = absolute_number_of_day - number_of_day_before_day_one

    seconds_of_day = 3600 * hour + 60 * minute + second
    unix_time = seconds_of_day + 24 * 3600 * julian_day

    return unix_time

def tosecs(t):
    """ Not my code! """
    return [int(datetime(*t[i]).timestamp()) for i in range(t.shape[0])]

uhf = r'Programming-tasks\Eiscat-experiment\files\beata_uhfa_orig'
vhf = r'Programming-tasks\Eiscat-experiment\files\beata_vhf_orig'

### Choose which datasets to use ###
dir = uhf
#####################################

q = []
for file in os.listdir(dir):
    if file.endswith(".mat"):
        q.append(os.path.join(dir, file))

[h,t,ne,Te,Ti,vi,dne,dTe,dTi,dvi,az,el,T,ranges] = guisdap_param2cell2regular(q)

# Explaining the output variables
def print_variables():
    """Explains the output variables of the function guisdap_param2cell2regular"""
    print('Variable description:')
    print('h - Altitudes (km), shape: ', h.shape)
    print('t - Time (unix time), shape: ', t.shape)
    print('ne - Electron density (m^-3), shape: ', ne.shape)
    print('Te - Electron temperature (K), shape: ', Te.shape)
    print('Ti - Ion temperatur (K), shape: ', Ti.shape)
    print('vi - Ion velocity (m/s), shape: ', vi.shape)
    print('dne - std of electron densities, shape: ', dne.shape)
    print('dTe - std of electron temperatures, shape: :', dTe.shape)
    print('dTi - std of ion temperatures, shape: :', dTi.shape)
    print('dvi - std of ion velocities, shape: :', dvi.shape)
    print('az - azimuth angle of radar (degrees), shape :', az.shape)
    print('el - elevation angle of radar (degrees), shape: ', el.shape)
    print('T - time and date [YYYY,MM,DD,hh,mm,ss], shape:', T.shape)
    print('ranges - array with ranges (km), shape: ', ranges.shape)
print_variables()

def measurement_interval(t):
    """Calculates the time interval between sequential measurements"""
    dt = []
    for i in range(len(t)):
        dt.append(t[i]-t[i-1])
    print(dt)

"""-----------Plotting the data-----------"""
# Electron density
fig = plt.figure()
ax = plt.axes()
pc = ax.pcolormesh(t, h[:,0], ne, cmap='jet', norm=colors.LogNorm(vmin=1e10, vmax=1e12))
ax.set_xlabel('Time (UTC)')
ax.set_ylabel('Altitude (km)')
ax.set_title('Electron density profiles')
fig.colorbar(pc, label='Electron density (m^-3)')
ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x))))
plt.show()

# Electron temperature
fig = plt.figure()
ax = plt.axes()
pc = ax.pcolormesh(t, h[:,0], Te, cmap='jet', vmin=1, vmax=4000)
ax.set_xlabel('Time (UTC)')
ax.set_ylabel('Altitude (km)')
ax.set_title('Electron temperature profiles')
fig.colorbar(pc, label='Electron temperature (K)')
ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x))))
plt.show()

# Ion temperature
fig = plt.figure()
ax = plt.axes()
pc = ax.pcolormesh(t, h[:,0], Ti, cmap='jet', vmin=1, vmax=3000)
ax.set_xlabel('Time (UTC)')
ax.set_ylabel('Altitude (km)')
ax.set_title('Ion temperature profiles')
fig.colorbar(pc, label='Ion temperature (K)')
ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x))))
plt.show()

# Ion velocity
fig = plt.figure()
ax = plt.axes()
pc = ax.pcolormesh(t, h[:,0], vi, cmap='jet', vmin=-200, vmax=200)
ax.set_xlabel('Time (UTC)')
ax.set_ylabel('Altitude (km)')
ax.set_title('Ion velocity profiles')
fig.colorbar(pc, label='Ion velocity (m/s)')
ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: time.strftime('%H:%M', time.gmtime(x))))
plt.show()